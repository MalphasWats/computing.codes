from pprint import pprint
import pypyodbc

DATABASE = 'BattleBots.accdb' # Change this to the filename for your database.

def sql_query(query):
    connection = pypyodbc.connect('Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=.\\%s'%DATABASE)
    cursor = connection.cursor()
    
    results = []
    cursor.execute(query)
    if cursor.description:
        columns = [column[0] for column in cursor.description]
        res = cursor.fetchall()
    
        for r in res:
            results.append(dict(zip(columns, r)))
    else:
        cursor.commit()
    connection.close()
    
    return results
    
    
# SELECT the Call Sign, Height, Top Speed and Mass for all of the BattleBots
bots = sql_query(""" ;""")

pprint(bots) # pretty print


# SELECT the Call Sign, Primary Weapon and Primary Weapon Damage 
# of all Bots with Primary Weapon Damage less than 100
bots = sql_query(""" ;""")

pprint(bots) # pretty print


# SELECT the Call Sign, Shield Capacity and Recharge Rate
# of all the Bots whose Recharge Rate is greater than 10.5
# Bots should be sorted alphabetically by name.


# SELECT Call Sign, Generator Output, Recharge Rate, Shield Capacity, 
# Armour and whether they have a Cloaking Device for all BattleBots who 
# have Shield Capacity greater than 2000 and have Armour greater than 1500. 
# Bots should be sorted alphabetically by name


# INSERT a new bot with the following attributes
# Call Sign: Firestorm
# Height: 3.1
# Mass: 28
# Top Speed: 25.2
# Generator Output: 6.2
# Recharge Rate: 3.4
# Shield Capacity: 2100
# Armour: 1600
# Primary Weapon: Ion Blaster
# Primary Weapon Damage: 764
# Secondary Weapon: Hornet Missiles
# Secondary Weapon Damage: 423
# Cloaking Device: No
# Date Created: 25/01/2012 14:00


# INSERT a new bot with the following attributes:
# Call Sign: Scout
# Height: 1.8
# Mass: 14
# Top Speed: 80
# Generator Output: 2.6
# Recharge Rate: 1.1
# Shield Capacity: 912
# Armour: 800
# Primary Weapon: Beam Laser
# Primary Weapon Damage: 440
# Secondary Weapon: EMP
# Secondary Weapon Damage: 220
# Cloaking Device: Yes
# Date Created: 25/01/2012 14:00


# UPDATE Primary Weapon Damage for Ferox from 514 to 545.#


# UPDATE the Top Speed for Firestorm from 25.2 to 26.8


# UPDATE the Primary Weapon for Nyx from a Rail Gun to a Plasteel Vibroblade



# DELETE the Scout BattleBot
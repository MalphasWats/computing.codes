/**
 * Skeleton Program code for the AQA COMP1 Summer 2013 examination
 * This code should be used in conjunction with the Preliminary Material
 * written by the AQA Programmer Team developed in the Netbeans 6.9.1 IDE
 * Additional classes AQAConsole, AQAReadTextFile and AQAWriteTextFile may
 * be used.
 *
 * A package name may be chosen and private and public modifiers added.
 * Permission to make these changes to the Skeleton Program does not
 * need to be obtained from AQA/AQA Programmer
 */

public class Main {
  AQAConsole console = new AQAConsole();

  /**
   * class PositionInFile introduced to allow use of pass by reference integer parameters
   */
  class PositionInFile {
    int position;
  }

  public Main() {
    String ciphertext;
    String plaintext;
    char choice;
    int amountToShift;
    PositionInFile start = new PositionInFile();
    PositionInFile end = new PositionInFile();
    int sizeOfRailFence;
    int n;
    ciphertext = "";
    plaintext = "";
    do {
      displayMenu();
      choice = getMenuChoice();
      switch (choice) {
        case 'a':
          plaintext = getTextFromUser();
          break;
        case 'b':
          displayPlaintext(plaintext);
          break;
        case 'd':
          ciphertext = getTextFromUser();
          break;
        case 'e':
          displayCiphertext(ciphertext);
          break;
        case 'g': {
          displayPlaintext(plaintext);
          amountToShift = getKeyForCaesarCipher();
          ciphertext = useCaesarCipher(plaintext, amountToShift);
          displayCiphertext(ciphertext);
          break;
        }
        case 'h': {
          displayPlaintext(plaintext);
          sizeOfRailFence = getSizeOfRailFence();
          ciphertext = encryptUsingRailFence(plaintext, sizeOfRailFence);
          displayCiphertext(ciphertext);
          break;
        }
        case 'j': {
          displayCiphertext(ciphertext);
          amountToShift = -getKeyForCaesarCipher();
          plaintext = useCaesarCipher(ciphertext, amountToShift);
          displayPlaintext(plaintext);
          break;
        }
        case 'k': {
          displayCiphertext(ciphertext);
          sizeOfRailFence = getSizeOfRailFence();
          plaintext = decryptUsingRailFence(ciphertext, sizeOfRailFence);
          displayPlaintext(plaintext);
          break;
        }
        case 'n': {
          getPositionsToUse(start, end);
          n = getValueForN();
          plaintext = everyNthCharacterSteganography(start.position, end.position, n);
          displayPlaintext(plaintext);
          break;
        }
      }
      if (choice != 'q') {
        console.print("Press enter key to continue");
        console.readLine();
      }
    } while (choice != 'q');
  }

  void displayMenu() {
    console.println();
    console.println("PLAINTEXT OPTIONS");
    console.println("  a.  Get plaintext from user");
    console.println("  b.  Display plaintext");
    console.println("CIPHERTEXT OPTIONS");
    console.println("  d.  Get ciphertext from user");
    console.println("  e.  Display ciphertext");
    console.println("ENCRYPT");
    console.println("  g.  Caesar cipher");
    console.println("  h.  Rail fence");
    console.println("DECRYPT");
    console.println("  j.  Caesar cipher");
    console.println("  k.  Rail fence");
    console.println("STEGANOGRAPHY");
    console.println("  n.  nth character (text from file)");
    console.println();
    console.print("Please select an option from the above list (or enter q to quit): ");
  }

  char getMenuChoice() {
    char menuChoice;
    menuChoice = console.readChar();
    console.println();
    return menuChoice;
  }

  String getTextFromUser() {
    String textFromUser;
    textFromUser = console.readLine("Please enter the text to use: ");
    return textFromUser;
  }

  /*
   * get startPositions and endPositions in file
   */
  void getPositionsToUse(PositionInFile start, PositionInFile end) {
    start.position = console.readInteger("Please enter the start position to use in the file: ");
    end.position = console.readInteger("Please enter the end position to use in the file: ");
  }

  String getTextFromFile(int startPosition, int endPosition) {
    char characterFromFile;
    String textFromFile;
    int count;
    AQAReadTextFile currentFile;
    currentFile = new AQAReadTextFile();
    currentFile.openTextFile("diary.txt");
    for (count = 1; count < startPosition; count++) {
      characterFromFile = currentFile.readChar();
    }
    textFromFile = "";
    for (count = startPosition; count <= endPosition; count++) {
      characterFromFile = currentFile.readChar();
      textFromFile += characterFromFile;
    }
    currentFile.closeFile();
    return textFromFile; 
  }

  int getKeyForCaesarCipher() {
    int key;
    key = console.readInteger("Enter the amount that shifts the plaintext alphabet to the ciphertext alphabet: ");
    return key;
  }

  String getTypeOfCharacter(int ASCIICode) {
    String typeOfCharacter;
    if (ASCIICode >= (int) 'A' && ASCIICode <= (int) 'Z') {
      typeOfCharacter = "Upper";
    } else {
      if (ASCIICode >= (int) 'a' && ASCIICode <= (int) 'z') {
        typeOfCharacter = "Lower";
      } else {
        typeOfCharacter = "Other";
      }
    }
    return typeOfCharacter;
  }

  int applyShiftToASCIICodeForCharacter(int ASCIICode, int amountToShift) {
    int newASCIICode;
    String typeOfCharacter;
    typeOfCharacter = getTypeOfCharacter(ASCIICode);
    if (!typeOfCharacter.equals("Other")) {
      if (typeOfCharacter.equals("Upper")) {
        newASCIICode = (26 + ASCIICode - (int) 'A' + amountToShift) % 26 + (int) 'A';
      } else {
        newASCIICode = (26 + ASCIICode - (int) 'a' + amountToShift) % 26 + (int) 'a';
      }
    } else {
      newASCIICode = ASCIICode;
    }
    return newASCIICode;
  }

  String useCaesarCipher(String originalText, int amountToShift) {
    String changedText;
    int count;
    int ASCIICode;
    changedText = "";
    for (count = 0; count < originalText.length(); count++) {
      ASCIICode = (int) originalText.charAt(count);
      ASCIICode = applyShiftToASCIICodeForCharacter(ASCIICode, amountToShift);
      changedText += (char) ASCIICode;
    }
    return changedText;
  }

  int getSizeOfRailFence() {
    int sizeOfRailFence;
    sizeOfRailFence = console.readInteger("Enter the number of lines in the rail fence: ");
    return sizeOfRailFence;
  }

  String encryptUsingRailFence(String originalText, int sizeOfRailFence) {
    int count1;
    int count2;
    String ciphertext;
    ciphertext = "";
    for (count1 = 1; count1 <= sizeOfRailFence; count1++) {
      count2 = count1 - 1;
      while (count2 < originalText.length()) {
        ciphertext = ciphertext + originalText.charAt(count2);
        count2 += sizeOfRailFence;
      }
    }
    return ciphertext;
  }

  String decryptUsingRailFence(String ciphertext, int sizeOfRailFence) {
    String plaintext;
    int noOfColumns;
    int noOfRows;
    int noOfCiphertextCharacters;
    int noOfCiphertextCharactersProcessed;
    int i;
    int j;
    int positionOfNextCharacter;
    int lastFullRowNo;
    int amountToReduceNoOfColumnsTimesjBy;
    int beginningOfNextRowIndex;
    plaintext = "";
    noOfCiphertextCharacters = ciphertext.length();
    /*
     * The ciphertext was created from a visualisation of the plaintext as
     * a two-dimensional grid of characters with no of rows = size of rail fence
     */
    noOfRows = sizeOfRailFence;
    noOfColumns = (int) noOfCiphertextCharacters / sizeOfRailFence;
    /*
     * If noOfCiphertextCharacters divides exactly all rows will be full
     * otherwise the last column will be incomplete and noOfColumns will not include last column
     */
    if (noOfCiphertextCharacters % sizeOfRailFence != 0) {
      noOfColumns++;
    }
    /* 
     * Calculate row no of last full row, 0 means every row full
     */
    lastFullRowNo = noOfCiphertextCharacters % sizeOfRailFence;
    noOfCiphertextCharactersProcessed = 0;
    for (i = 1; i <= noOfColumns; i++) { /* Work along the columns building the plaintext a column at a time */
      amountToReduceNoOfColumnsTimesjBy = 0;
      for (j = 0; j < noOfRows; j++) {   /* Work down the rows building the plaintext */
        if (lastFullRowNo != 0) {  /* Last column doesn't have a character in every row */
          if (j > lastFullRowNo) { /* There are shorter rows to skip */
            amountToReduceNoOfColumnsTimesjBy++;
          }
        }
        /* 
         * noOfColumns * j locates in ciphertext beginning of each row
         */
        beginningOfNextRowIndex = noOfColumns * j - amountToReduceNoOfColumnsTimesjBy;
        positionOfNextCharacter = beginningOfNextRowIndex + i - 1;
        noOfCiphertextCharactersProcessed++;
        if (noOfCiphertextCharactersProcessed <= noOfCiphertextCharacters) {
          plaintext += ciphertext.charAt(positionOfNextCharacter);
        }
      }
    }
    return plaintext;
  }
  
  int getValueForN() {
    int n;
    n = console.readInteger("Enter the value of n: ");
    return n;
  }

  String everyNthCharacterSteganography(int startPosition, int endPosition, int n) {
    String hiddenMessage;
    int currentPosition;
    currentPosition = startPosition;
    hiddenMessage = "";
    while (currentPosition <= endPosition) {
      hiddenMessage += getTextFromFile(currentPosition, currentPosition);
      currentPosition += n;
    }
    return hiddenMessage;
  }

  void displayPlaintext(String textToDisplay) {
    console.println();
    console.print("The plaintext is: ");
    console.println(textToDisplay);
  }

  void displayCiphertext(String textToDisplay) {
    console.println();
    console.print("The ciphertext is: ");
    console.println(textToDisplay);
  }

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    new Main();
  }
}
